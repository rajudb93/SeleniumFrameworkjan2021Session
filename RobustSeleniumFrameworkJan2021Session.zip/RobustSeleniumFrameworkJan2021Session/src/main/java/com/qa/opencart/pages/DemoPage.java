package com.qa.opencart.pages;

public class DemoPage {
	
	public void demo() {
		System.out.println("demo page");
	}
	
	

}
